package com.lifebank.pojo.authentication;

import java.io.Serializable;

import lombok.Data;

@Data
public class AuthenticationResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String tkn;
	private String lifeBankNum;
}
