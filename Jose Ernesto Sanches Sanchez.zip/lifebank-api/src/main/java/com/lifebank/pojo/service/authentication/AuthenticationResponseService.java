package com.lifebank.pojo.service.authentication;

public class AuthenticationResponseService {

}
