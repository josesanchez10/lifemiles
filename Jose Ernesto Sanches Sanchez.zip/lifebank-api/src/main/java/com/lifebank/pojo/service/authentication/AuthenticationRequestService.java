package com.lifebank.pojo.service.authentication;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class AuthenticationRequestService {
	private String use;
	private String pass;
}
