package com.lifebank.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.pojo.authentication.AuthenticationRequest;
import com.lifebank.pojo.authentication.AuthenticationResponse;
import com.lifebank.pojo.general.Envelope;
import com.lifebank.process.AuthenticationProcess;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@RequestMapping("${service.url-base}")
public class AuthenticationController {
	private AuthenticationProcess loginProcess;
	
	@PostMapping("/authentication")
	public Envelope<Map<String, String>, AuthenticationResponse> Login(@RequestBody AuthenticationRequest request) {
		return loginProcess.process(request);
	}
}