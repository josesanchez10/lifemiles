package com.lifebank.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class HeaderBuilder {
	private Environment env;
	
	public Map<String, String> createSuccessHeader() {
		Map<String, String> header = new HashMap<>();
		
		header.put(
			env.getProperty("service.configuration.response-code.code-property-name"),
			env.getProperty("service.configuration.response-code.success.code")
		);
		header.put(
			env.getProperty("service.configuration.response-code.message-property-name"),
			env.getProperty("service.configuration.response-code.success.message")
		);
		
		return header;
	}
	
	public Map<String, String> createInvalidCredentialsHeader() {
		Map<String, String> header = new HashMap<>();
		
		header.put(
			env.getProperty("service.configuration.response-code.code-property-name"),
			env.getProperty("service.configuration.response-code.invalid-credentials.code")
		);
		header.put(
			env.getProperty("service.configuration.response-code.message-property-name"),
			env.getProperty("service.configuration.response-code.invalid-credentials.message")
		);
		
		return header;
	}
	
	public Map<String, String> createInvalidDataHeader() {
		Map<String, String> header = new HashMap<>();
		
		header.put(
			env.getProperty("service.configuration.response-code.code-property-name"),
			env.getProperty("service.configuration.response-code.invalid-data.code")
		);
		header.put(
			env.getProperty("service.configuration.response-code.message-property-name"),
			env.getProperty("service.configuration.response-code.invalid-data.message")
		);
		
		return header;
	}
	
	public Map<String, String> createErrorHeader() {
		Map<String, String> header = new HashMap<>();
		
		header.put(
			env.getProperty("service.configuration.response-code.code-property-name"),
			env.getProperty("service.configuration.response-code.error.code")
		);
		header.put(
			env.getProperty("service.configuration.response-code.message-property-name"),
			env.getProperty("service.configuration.response-code.error.message")
		);
		
		return header;
	}
}
