package com.lifebank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifebankApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifebankApiApplication.class, args);
	}

}
