package com.lifebank.repository;

import com.lifebank.pojo.authentication.AuthenticationRequest;

public interface AuthenticationRepository<T> {
	T requestAccess(AuthenticationRequest request);
}
