package com.lifebank.repository.impl;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.lifebank.pojo.authentication.AuthenticationRequest;
import com.lifebank.pojo.service.authentication.AuthenticationResponseService;
import com.lifebank.repository.AuthenticationRepository;
import com.lifebank.utility.ClientRest;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@NoArgsConstructor
@AllArgsConstructor
public class AuthenticationRepImpl implements AuthenticationRepository<AuthenticationResponseService> {
	private ClientRest api;
	private Environment env;
	
	@Override
	public  AuthenticationResponseService requestAccess(AuthenticationRequest request) {
		try {
			return api.call(
					env.getProperty("service.external.endpoint.authenticatio-login"),
					HttpMethod.POST,
					null,
					request,
					new ParameterizedTypeReference<AuthenticationResponseService>() {}
				);
		} catch(Exception e) {
			log.error("Error requesting countries: {}", e.getMessage(), e);
			return null;
		}
	}
}
