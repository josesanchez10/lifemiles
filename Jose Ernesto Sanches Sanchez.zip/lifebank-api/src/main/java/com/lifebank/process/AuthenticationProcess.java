package com.lifebank.process;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.lifebank.pojo.authentication.AuthenticationRequest;
import com.lifebank.pojo.authentication.AuthenticationResponse;
import com.lifebank.pojo.general.Envelope;
import com.lifebank.utility.HeaderBuilder;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class AuthenticationProcess {
	private HeaderBuilder headerBuilder;
	
	public Envelope<Map<String, String>, AuthenticationResponse> process(AuthenticationRequest request) {
		try {
			AuthenticationResponse response = new AuthenticationResponse();
			
			if(request.getPassword() == null || request.getUsername() == null) {
				return new Envelope<>(headerBuilder.createInvalidDataHeader(), null);
			}
			
			//response.setToken(JwtHelper.encode(content, signer));
			
			response.setLifeBankNum("123");
			response.setTkn("token");
			
			return new Envelope<>(headerBuilder.createSuccessHeader(), response);
		} catch (Exception e) {
			log.error("Error in Authentication ",e);
			return new Envelope<>(headerBuilder.createErrorHeader(), null);
		}
		
	}
}
